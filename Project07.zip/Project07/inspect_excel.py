from openpyxl import load_workbook
import os
path = r'D:\作业\Java高级编程技术实践\EXP07_GS2402_20241111167\Project07\files\教学记录表_软国Java编程实践_百度链接和QQ邮箱.xlsx'
print('exists', os.path.exists(path))
wb = load_workbook(path, data_only=True)
ws = wb.active
print('sheet', ws.title)
print('max_row', ws.max_row, 'max_col', ws.max_column)
for i in range(1, min(12, ws.max_row + 1)):
    row = [cell.value for cell in ws[i]]
    print(i, row)
