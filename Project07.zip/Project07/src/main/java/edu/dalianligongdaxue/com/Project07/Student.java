package edu.dalianligongdaxue.com.Project07;

public class Student {
	private String id;
	private String name;
	private String className;
	private String baiduLink;
	private String qqEmail;
	
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public void setBaiduLink(String baiduLink) {
		this.baiduLink = baiduLink;
	}
	public void setQQEmail(String qqEmail) {
		this.qqEmail = qqEmail;
	}
	public String getId() {
		return this.id;
	}
	public String getName() {
		return this.name;
	}
	public String getClassName() {
		return this.className;
	}
	public String getBaiduLink() {
		return this.baiduLink;
	}
	public String getQQEmail() {
		return this.qqEmail;
	}
	
	
	public Student(String id, String name, String className,String baiduLink, String qqEmail) {
		this.id = id;
		this.name = name;
		this.className = className;
		this.baiduLink = baiduLink;
		this.qqEmail = qqEmail;
		
	}

}
