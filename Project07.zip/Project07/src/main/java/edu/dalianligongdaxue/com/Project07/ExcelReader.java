package edu.dalianligongdaxue.com.Project07;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

    private static final DataFormatter DATA_FORMATTER = new DataFormatter();

    public static List<Student> readStudentFromExcel(String filePath) throws IOException {
        List<Student> students = new ArrayList<>();
        File excelFile = new File(filePath);
        if (!excelFile.exists()) {
            throw new IOException("Excel文件不存在: " + filePath);
        }

        try (FileInputStream fis = new FileInputStream(excelFile);
             Workbook workbook = new XSSFWorkbook(fis)) {

            for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
                Sheet sheet = workbook.getSheetAt(sheetIndex);
                if (sheet == null) {
                    continue;
                }

                Map<String, Integer> headerIndexes = new HashMap<>();
                boolean headerFound = false;

                for (Row row : sheet) {
                    if (row == null) {
                        continue;
                    }

                    if (!headerFound) {
                        headerIndexes = readHeaderIndexes(row);
                        if (isValidHeader(headerIndexes)) {
                            headerFound = true;
                        }
                        continue;
                    }

                    if (isBlankRow(row)) {
                        continue;
                    }

                    String studentId = getCellStringValue(getCellByHeader(row, headerIndexes, "学号"));
                    String studentName = getCellStringValue(getCellByHeader(row, headerIndexes, "姓名"));
                    String studentClassName = getCellStringValue(getCellByHeader(row, headerIndexes, "班级"));
                    String studentBaiduLink = getCellStringValue(getCellByHeader(row, headerIndexes, "百度链接"));
                    String studentQQEmail = getCellStringValue(getCellByHeader(row, headerIndexes, "QQ邮箱"));

                    if (studentId.isEmpty() && studentName.isEmpty() && studentClassName.isEmpty()
                            && studentBaiduLink.isEmpty() && studentQQEmail.isEmpty()) {
                        continue;
                    }

                    students.add(new Student(studentId, studentName, studentClassName, studentBaiduLink, studentQQEmail));
                }

                if (!students.isEmpty()) {
                    break;
                }
            }
        }

        return students;
    }

    private static String getCellStringValue(Cell cell) {
        if (cell == null) {
            return "";
        }
        return DATA_FORMATTER.formatCellValue(cell).trim();
    }

    private static Cell getCellByHeader(Row row, Map<String, Integer> headerIndexes, String headerName) {
        Integer index = headerIndexes.get(headerName);
        if (index == null) {
            return null;
        }
        return row.getCell(index, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
    }

    private static boolean isBlankRow(Row row) {
        if (row == null) {
            return true;
        }
        for (int col = 0; col < row.getLastCellNum(); col++) {
            Cell cell = row.getCell(col, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (!getCellStringValue(cell).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private static Map<String, Integer> readHeaderIndexes(Row row) {
        Map<String, Integer> headerIndexes = new HashMap<>();
        if (row == null) {
            return headerIndexes;
        }

        for (int col = 0; col < row.getLastCellNum(); col++) {
            String value = getCellStringValue(row.getCell(col, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL));
            String normalized = normalizeHeader(value);
            if (normalized.contains("序号")) {
                headerIndexes.put("序号", col);
            } else if (normalized.contains("学号")) {
                headerIndexes.put("学号", col);
            } else if (normalized.contains("姓名")) {
                headerIndexes.put("姓名", col);
            } else if (normalized.contains("班级")) {
                headerIndexes.put("班级", col);
            } else if (normalized.contains("百度链接") || normalized.contains("百度") || normalized.contains("链接")) {
                headerIndexes.put("百度链接", col);
            } else if (normalized.contains("qq邮箱") || normalized.contains("邮箱")) {
                headerIndexes.put("QQ邮箱", col);
            }
        }
        return headerIndexes;
    }

    private static String normalizeHeader(String value) {
        if (value == null) {
            return "";
        }
        return value.replaceAll("\\s+", "").toLowerCase();
    }

    private static boolean isValidHeader(Map<String, Integer> headerIndexes) {
        return headerIndexes.containsKey("学号")
                && headerIndexes.containsKey("姓名")
                && (headerIndexes.containsKey("QQ邮箱") || headerIndexes.containsKey("百度链接"));
    }
}
