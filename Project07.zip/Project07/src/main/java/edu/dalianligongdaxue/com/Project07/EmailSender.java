package edu.dalianligongdaxue.com.Project07;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import java.io.File;
import java.util.Properties;

public class EmailSender {
	
	public static void sendEmailWithAttachment(String toEmail, String fromEmail, String subject, String body, File attachmentFile, String authorizationCode) throws MessagingException {
		
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.qq.com"); // QQ邮箱的SMTP服务器地址[reference:21]
        props.put("mail.smtp.port", "587");        // 端口号
        props.put("mail.smtp.auth", "true");        // 需要身份验证
        props.put("mail.smtp.starttls.enable", "true"); // 启用TLS加密
        
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, authorizationCode);
            }
        });
        
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(fromEmail));
        message.setSubject(subject);
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
        
        MimeBodyPart textPart = new MimeBodyPart();
        textPart.setText(body);
        
        MimeBodyPart attachmentPart = new MimeBodyPart();
        DataSource source = new FileDataSource(attachmentFile);
        attachmentPart.setDataHandler(new DataHandler(source));
        attachmentPart.setFileName(attachmentFile.getName());
        
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(textPart);
        multipart.addBodyPart(attachmentPart);
        
        message.setContent(multipart);
        Transport.send(message);
		
	}
}

