package edu.dalianligongdaxue.com.Project07;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;

import org.docx4j.Docx4J;
import org.docx4j.fonts.IdentityPlusMapper;
import org.docx4j.fonts.Mapper;
import org.docx4j.fonts.PhysicalFonts;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.Text;

public class DocumentGenerator {

    private static final ObjectFactory WML_FACTORY = new ObjectFactory();

    public static File generateDocument(Student student, String templatePath, File wordOutputDir, File pdfOutputDir) throws Exception {
        WordprocessingMLPackage wordPackage = WordprocessingMLPackage.load(new File(templatePath));
        MainDocumentPart document = wordPackage.getMainDocumentPart();

        Mapper fontMapper = new IdentityPlusMapper();
        fontMapper.put("宋体", PhysicalFonts.get("Simsum"));
        fontMapper.put("微软雅黑", PhysicalFonts.get("Microsoft Yahei"));
        wordPackage.setFontMapper(fontMapper);

        // 手动合并分散在多个<w:r>中的${...}变量（修复Word编辑器拆分问题）
        mergeSplitVariables(document);

        Map<String, String> mappings = new HashMap<>();
        mappings.put("Name", safeValue(student.getName()));
        mappings.put("name", safeValue(student.getName()));
        mappings.put("Baidulink", safeValue(student.getBaiduLink()));
        mappings.put("BaiduLink", safeValue(student.getBaiduLink()));
        mappings.put("baidulink", safeValue(student.getBaiduLink()));
        document.variableReplace(mappings);

        String safeClassName = sanitizeFileName(student.getClassName());
        String safeName = sanitizeFileName(student.getName());
        String safeId = sanitizeFileName(student.getId());
        String safeLink = sanitizeFileName(student.getBaiduLink());

        String wordFileName = String.format("%s_%s_%s_%s.docx", safeClassName, safeName, safeId, safeLink);
        File wordFile = new File(wordOutputDir, wordFileName);
        wordOutputDir.mkdirs();
        wordPackage.save(wordFile);

        String pdfFileName = wordFileName.replace(".docx", ".pdf");
        File pdfFile = new File(pdfOutputDir, pdfFileName);
        pdfOutputDir.mkdirs();

        try (FileOutputStream fos = new FileOutputStream(pdfFile)) {
            Docx4J.toPDF(wordPackage, fos);
        }
        return pdfFile;
    }

    /**
     * 遍历所有段落，将分散在多个 &lt;w:r&gt; 中的 ${...} 占位符合并到单个 &lt;w:r&gt; 中。
     * 这解决了 Word 编辑器因格式差异将 ${Name} 拆分为 ${ / Name / } 三个 run 的问题。
     */
    private static void mergeSplitVariables(MainDocumentPart document) {
        List<Object> bodyContent = document.getContent();
        for (Object item : bodyContent) {
            if (item instanceof P) {
                mergeSplitRunsInParagraph((P) item);
            }
        }
    }

    private static void mergeSplitRunsInParagraph(P paragraph) {
        List<Object> children = paragraph.getContent();
        // 收集所有 <w:r> 元素及其文本
        List<RunEntry> runEntries = new ArrayList<>();
        for (Object child : children) {
            R run = getRun(child);
            if (run != null) {
                String text = getRunText(run);
                runEntries.add(new RunEntry(run, text, child));
            }
        }

        // 扫描连续的 run，寻找 ${...} 模式
        for (int i = 0; i < runEntries.size(); i++) {
            String combined = "";
            int end = i;
            // 尝试从 runEntries[i] 开始拼接，看是否能形成一个完整的 ${...}
            for (int j = i; j < runEntries.size(); j++) {
                combined += runEntries.get(j).text;
                if (combined.startsWith("${") && combined.contains("}")) {
                    end = j;
                    break;
                }
                if (combined.length() > 200) {
                    break; // 安全限制：避免无限拼接
                }
            }

            // 如果跨越了多个 run（end > i）且形成了完整的 ${...} 模式
            if (end > i && combined.startsWith("${") && combined.contains("}")) {
                // 将 runEntries[i..end] 合并到第一个 run 中
                R firstRun = runEntries.get(i).run;
                setRunText(firstRun, combined);

                // 从 paragraph 中删除后续的 run（i+1 到 end）
                for (int k = end; k > i; k--) {
                    children.remove(runEntries.get(k).childObj);
                }

                // 更新 runEntries 列表（移除已合并的条目）
                for (int k = end; k > i; k--) {
                    runEntries.remove(k);
                }
                // 更新第一个条目的文本
                runEntries.get(i).text = combined;
            }
        }
    }

    /**
     * 如果 child 是 &lt;w:r&gt; 元素则返回该 R 对象，否则返回 null。
     */
    @SuppressWarnings("unchecked")
    private static R getRun(Object child) {
        if (child instanceof R) {
            return (R) child;
        }
        if (child instanceof JAXBElement) {
            JAXBElement<?> jaxb = (JAXBElement<?>) child;
            if (jaxb.getDeclaredType().equals(R.class)) {
                return (R) jaxb.getValue();
            }
        }
        return null;
    }

    /**
     * 获取一个 &lt;w:r&gt; 中的所有文本内容（拼接所有 &lt;w:t&gt; 元素）。
     */
    private static String getRunText(R run) {
        StringBuilder sb = new StringBuilder();
        for (Object content : run.getContent()) {
            if (content instanceof JAXBElement) {
                JAXBElement<?> jaxb = (JAXBElement<?>) content;
                if (jaxb.getValue() instanceof Text) {
                    Text text = (Text) jaxb.getValue();
                    String value = text.getValue();
                    if (value != null) {
                        sb.append(value);
                    }
                }
            }
        }
        return sb.toString();
    }

    /**
     * 设置一个 &lt;w:r&gt; 的文本内容（保留原有空格处理属性）。
     */
    @SuppressWarnings("unchecked")
    private static void setRunText(R run, String newText) {
        List<Object> content = run.getContent();
        // 移除所有现有的 Text 元素
        content.removeIf(c -> {
            if (c instanceof JAXBElement) {
                return ((JAXBElement<?>) c).getValue() instanceof Text;
            }
            return false;
        });
        // 添加新的 Text
        Text text = WML_FACTORY.createText();
        text.setValue(newText);
        text.setSpace("preserve"); // 保留空格
        content.add(WML_FACTORY.createRT(text));
    }

    // ---------- 辅助内部类 ----------

    private static class RunEntry {
        final R run;
        String text;
        final Object childObj;

        RunEntry(R run, String text, Object childObj) {
            this.run = run;
            this.text = text;
            this.childObj = childObj;
        }
    }

    // ---------- 通用工具方法 ----------

    private static String safeValue(String value) {
        return value == null ? "" : value;
    }

    private static String sanitizeFileName(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "unknown";
        }
        String sanitized = value.trim().replaceAll("[\\\\/:*?\"<>|\\s]+", "_");
        sanitized = sanitized.replaceAll("[\\r\\n]+", "_");
        return sanitized.length() > 80 ? sanitized.substring(0, 80) : sanitized;
    }
}
