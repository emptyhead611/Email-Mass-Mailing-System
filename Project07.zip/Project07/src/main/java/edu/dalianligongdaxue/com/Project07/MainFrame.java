package edu.dalianligongdaxue.com.Project07; 
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * 这是整个软件的图形界面（窗口）
 * 用户通过这个窗口选择文件、输入邮箱授权码、查看运行日志
 */
public class MainFrame extends JFrame {

    // ---------- 界面上的输入组件（用户要填的东西）----------
    private JTextField excelPathField;      // 显示选中的Excel文件路径
    private JTextField templatePathField;   // 显示选中的Word模板路径
    private JTextField outputDirField;      // 显示输出文件夹路径
    private JTextField emailField;          // 发件人的QQ邮箱
    private JPasswordField authCodeField;   // QQ邮箱授权码（输入时显示为星号）

    private JTextArea logArea;              // 日志显示区（多行文本）
    private JButton startButton;            // 开始按钮

    // ---------- 构造方法（窗口一打开就会自动执行）----------
    public MainFrame() {
        // 1. 设置窗口标题
        setTitle("📧 批量通知文件生成与群发工具 v1.0");
        // 2. 设置窗口大小（宽700，高600）
        setSize(700, 600);
        // 3. 设置点击窗口右上角“×”时，彻底关闭程序
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 4. 设置窗口在屏幕正中间显示
        setLocationRelativeTo(null);

        // 5. 调用下面的方法，把按钮、输入框等所有组件摆到窗口里
        initUI();

        // 6. 让窗口显示出来
        setVisible(true);
    }

    // ---------- 装修界面：把所有按钮、输入框摆好 ----------
    private void initUI() {
        // 整个窗口的布局：上（控制面板） + 中（日志区） + 下（开始按钮）
        setLayout(new BorderLayout(10, 10)); // 10,10 是组件之间的间距

        // ========== 上部：控制面板（选择文件 + 填写邮箱） ==========
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // 每个组件之间的边距
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0; // 让组件可以横向拉伸

        // ---------- 第1行：Excel文件选择 ----------
        gbc.gridx = 0; gbc.gridy = 0; // 第0列，第0行
        topPanel.add(new JLabel("📂 Excel数据表:"), gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 2.0;
        excelPathField = new JTextField();
        topPanel.add(excelPathField, gbc);

        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0.5;
        JButton excelBtn = new JButton("浏览...");
        excelBtn.addActionListener(e -> chooseFile(excelPathField, "xlsx"));
        topPanel.add(excelBtn, gbc);

        // ---------- 第2行：Word模板选择 ----------
        gbc.gridx = 0; gbc.gridy = 1;
        topPanel.add(new JLabel("📄 Word模板:"), gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 2.0;
        templatePathField = new JTextField();
        topPanel.add(templatePathField, gbc);

        gbc.gridx = 2; gbc.gridy = 1; gbc.weightx = 0.5;
        JButton templateBtn = new JButton("浏览...");
        templateBtn.addActionListener(e -> chooseFile(templatePathField, "docx"));
        topPanel.add(templateBtn, gbc);

        // ---------- 第3行：输出文件夹 ----------
        gbc.gridx = 0; gbc.gridy = 2;
        topPanel.add(new JLabel("📁 输出目录:"), gbc);

        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 2.0;
        outputDirField = new JTextField();
        outputDirField.setText(System.getProperty("user.dir") + "/output"); // 默认在项目根目录下的output文件夹
        topPanel.add(outputDirField, gbc);

        gbc.gridx = 2; gbc.gridy = 2; gbc.weightx = 0.5;
        JButton outputBtn = new JButton("浏览...");
        outputBtn.addActionListener(e -> chooseFolder(outputDirField));
        topPanel.add(outputBtn, gbc);

        // ---------- 第4行：发件人邮箱 ----------
        gbc.gridx = 0; gbc.gridy = 3;
        topPanel.add(new JLabel("📧 发件人QQ邮箱:"), gbc);

        gbc.gridx = 1; gbc.gridy = 3; gbc.weightx = 2.0;
        emailField = new JTextField();
        emailField.setToolTipText("请输入你的QQ邮箱地址，例如：123456789@qq.com");
        topPanel.add(emailField, gbc);

        gbc.gridx = 2; gbc.gridy = 3; gbc.weightx = 0.5;
        topPanel.add(new JLabel(""), gbc); // 占位，保持对齐

        // ---------- 第5行：QQ邮箱授权码 ----------
        gbc.gridx = 0; gbc.gridy = 4;
        topPanel.add(new JLabel("🔑 邮箱授权码:"), gbc);

        gbc.gridx = 1; gbc.gridy = 4; gbc.weightx = 2.0;
        authCodeField = new JPasswordField();
        authCodeField.setToolTipText("⚠️ 不是QQ密码！去QQ邮箱设置里生成授权码");
        topPanel.add(authCodeField, gbc);

        gbc.gridx = 2; gbc.gridy = 4; gbc.weightx = 0.5;
        JButton helpBtn = new JButton("❓ 怎么获取？");
        helpBtn.addActionListener(e -> showAuthCodeHelp());
        topPanel.add(helpBtn, gbc);

        // 把控制面板放到窗口的北部（上方）
        add(topPanel, BorderLayout.NORTH);

        // ========== 中部：日志显示区（带滚动条） ==========
        logArea = new JTextArea();
        logArea.setEditable(false); // 用户只能看，不能改
        logArea.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        logArea.setBackground(new Color(240, 248, 255)); // 淡蓝色背景
        logArea.setText("📌 欢迎使用！\n请先选择Excel文件和Word模板，然后点击下方的【开始生成并发送】按钮。\n");

        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane, BorderLayout.CENTER);

        // ========== 下部：开始按钮 ==========
        startButton = new JButton("🚀 开始生成并发送");
        startButton.setFont(new Font("微软雅黑", Font.BOLD, 18));
        startButton.setBackground(new Color(50, 205, 50)); // 鲜绿色背景
        startButton.setForeground(Color.WHITE);
        // 点击按钮时，启动后台任务
        startButton.addActionListener(e -> startProcess());

        // 把按钮放在窗口的南部（下方），并加一点内边距
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(startButton);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    // ---------- 辅助方法1：选择文件（.xlsx 或 .docx） ----------
    private void chooseFile(JTextField textField, String extension) {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File(System.getProperty("user.home") + "/Desktop"));
        // 设置文件过滤器，只显示指定后缀的文件
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                extension.equals("xlsx") ? "Excel文件 (*.xlsx)" : "Word模板 (*.docx)",
                extension);
        chooser.setFileFilter(filter);

        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chooser.getSelectedFile();
            textField.setText(selectedFile.getAbsolutePath());
        }
    }

    // ---------- 辅助方法2：选择文件夹 ----------
    private void chooseFolder(JTextField textField) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); // 只能选文件夹
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedDir = chooser.getSelectedFile();
            textField.setText(selectedDir.getAbsolutePath());
        }
    }

    // ---------- 辅助方法3：显示授权码获取帮助 ----------
    private void showAuthCodeHelp() {
        JOptionPane.showMessageDialog(this,
                "📖 获取QQ邮箱授权码步骤：\n" +
                        "1. 登录 QQ 邮箱 (mail.qq.com)\n" +
                        "2. 点击左上角【设置】->【帐户】\n" +
                        "3. 在【POP3/IMAP/SMTP/Exchange/CardDAV/CalDAV服务】中\n" +
                        "   找到【IMAP/SMTP服务】，点击【开启】\n" +
                        "4. 按照提示发送短信后，会得到一串16位字母数字混合的授权码\n" +
                        "5. 把那段授权码复制到上面的输入框里（注意不要有空格）",
                "获取授权码帮助",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------- 核心逻辑：点击“开始”按钮后执行 ----------
    private void startProcess() {
        // 1. 先检查用户有没有填完整信息
        String excelPath = excelPathField.getText().trim();
        String templatePath = templatePathField.getText().trim();
        String outputDir = outputDirField.getText().trim();
        String senderEmail = emailField.getText().trim();
        String authCode = new String(authCodeField.getPassword()).trim();

        if (excelPath.isEmpty() || templatePath.isEmpty() || outputDir.isEmpty() ||
                senderEmail.isEmpty() || authCode.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ 所有输入框都不能为空！请检查后重试。", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. 检查文件是否存在
        if (!new File(excelPath).exists()) {
            JOptionPane.showMessageDialog(this, "❌ Excel文件不存在，请重新选择！", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!new File(templatePath).exists()) {
            JOptionPane.showMessageDialog(this, "❌ Word模板文件不存在，请重新选择！", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 3. 禁用按钮，防止用户重复点击
        startButton.setEnabled(false);
        startButton.setText("⏳ 处理中，请稍候...");
        logArea.append("\n========== 开始处理 ==========\n");

        // 4. 启动一个后台线程（防止界面卡死）
        SwingWorker<Void, String> worker = new SwingWorker<Void, String>() {
            @Override
            protected Void doInBackground() throws Exception {
                // ---------- 第一步：读取Excel ----------
                publish("📖 正在读取Excel文件...");
                List<Student> students = ExcelReader.readStudentFromExcel(excelPath);
                int total = students.size();
                publish("✅ 成功读取 " + total + " 条学生记录。\n");

                // 创建输出目录
                File wordDir = new File(outputDir, "word");
                File pdfDir = new File(outputDir, "pdf");
                wordDir.mkdirs();
                pdfDir.mkdirs();

                // ---------- 第二步：循环处理每个学生 ----------
                for (int i = 0; i < students.size(); i++) {
                    Student student = students.get(i);
                    String studentName = student.getName();
                    String qqEmail = student.getQQEmail();

                    // 跳过没有邮箱的学生
                    if (qqEmail == null || qqEmail.isEmpty()) {
                        publish("⚠️ 第 " + (i + 1) + " 位 " + studentName + " 没有QQ邮箱，已跳过。");
                        continue;
                    }

                    try {
                        publish("🔄 正在处理第 " + (i + 1) + "/" + total + " 位：" + studentName);

                        // 2.1 生成Word和PDF
                        File pdfFile = DocumentGenerator.generateDocument(student, templatePath, wordDir, pdfDir);
                        publish("   ✅ Word和PDF已生成");

                        if (!pdfFile.exists()) {
                            publish("   ❌ PDF文件不存在，跳过发送邮件");
                            continue;
                        }

                        // 2.3 发送邮件（带PDF附件）
                        String subject = "【通知】你的作业百度链接已生成";
                        String body = "同学 " + studentName + "，你好！\n\n你的作业百度链接已生成，请查看附件中的PDF文件。\n\n（本邮件由系统自动发送，请勿回复。）";

                        EmailSender.sendEmailWithAttachment(
                                qqEmail,
                                senderEmail,
                                subject,
                                body,
                                pdfFile,
                                authCode
                        );
                        publish("   📧 邮件已发送至 " + qqEmail);

                        // 控制发送频率，防止QQ邮箱封号（每3秒发一封）
                        Thread.sleep(3000);

                    } catch (Exception e) {
                        publish("   ❌ 处理失败：" + e.getMessage());
                        e.printStackTrace(); // 打印到控制台，方便调试
                    }
                } // end for

                publish("\n========== 全部处理完成！ ==========");
                return null;
            }

            @Override
            protected void process(List<String> chunks) {
                // 把后台发来的日志消息，逐行追加到界面上的日志区域
                for (String msg : chunks) {
                    logArea.append(msg + "\n");
                }
                // 自动滚动到日志的最底部
                logArea.setCaretPosition(logArea.getDocument().getLength());
            }

            @Override
            protected void done() {
                // 后台任务结束后，恢复按钮状态
                startButton.setEnabled(true);
                startButton.setText("🚀 开始生成并发送");
                JOptionPane.showMessageDialog(MainFrame.this, "✅ 所有任务已执行完毕！请查看日志。", "完成", JOptionPane.INFORMATION_MESSAGE);
            }
        };

        // 启动后台线程
        worker.execute();
    }

    // ---------- main方法：程序的入口 ----------
    public static void main(String[] args) {
        // 在Swing专用的线程里创建窗口（保证线程安全）
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}