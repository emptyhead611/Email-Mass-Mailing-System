package edu.dalianligongdaxue.com.Project07;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.zip.ZipFile;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class DocumentGeneratorTest {

    @Test
    public void shouldReplaceTemplatePlaceholdersAndCreatePdfFile() throws Exception {
        File tempDir = Files.createTempDirectory("docgen-test").toFile();
        File wordOutputDir = new File(tempDir, "word");
        File pdfOutputDir = new File(tempDir, "pdf");

        Student student = new Student("202401", "张三", "软件2402", "https://pan.baidu.com/s/123456", "test@qq.com");
        File generatedPdf = DocumentGenerator.generateDocument(
                student,
                "files/BaiDuLink_Template.docx",
                wordOutputDir,
                pdfOutputDir
        );

        assertTrue("PDF file should be created", generatedPdf.exists());
        assertTrue("Word file should be created", new File(wordOutputDir, generatedPdf.getName().replace(".pdf", ".docx")).exists());

        File wordFile = new File(wordOutputDir, generatedPdf.getName().replace(".pdf", ".docx"));
        try (ZipFile zipFile = new ZipFile(wordFile)) {
            try (InputStream inputStream = zipFile.getInputStream(zipFile.getEntry("word/document.xml"))) {
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
                String documentXml = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
                assertTrue("Student name should appear in generated document", documentXml.contains("张三"));
                assertTrue("Baidu link should appear in generated document", documentXml.contains("https://pan.baidu.com/s/123456"));
                assertFalse("Template placeholder should be replaced", documentXml.contains("${Name}"));
                assertFalse("Template placeholder should be replaced", documentXml.contains("${Baidulink}"));
            }
        }
    }
}
