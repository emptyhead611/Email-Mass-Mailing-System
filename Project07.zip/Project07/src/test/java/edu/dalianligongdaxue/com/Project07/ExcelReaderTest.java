package edu.dalianligongdaxue.com.Project07;

import java.io.File;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class ExcelReaderTest {

    @Test
    public void shouldReadStudentsFromRealExcelFile() throws Exception {
        File excelFile = new File("files/教学记录表_软国Java编程实践_百度链接和QQ邮箱.xlsx");
        assertTrue("Excel file should exist", excelFile.exists());

        List<Student> students = ExcelReader.readStudentFromExcel(excelFile.getAbsolutePath());
        System.out.println("students=" + students.size());
        for (int i = 0; i < Math.min(5, students.size()); i++) {
            Student student = students.get(i);
            System.out.println((i + 1) + ": id=" + student.getId() + ", name=" + student.getName() + ", qq=" + student.getQQEmail());
        }
        assertFalse("Should read at least one student", students.isEmpty());
        assertTrue("Should contain QQ emails", students.stream().anyMatch(student -> student.getQQEmail() != null && !student.getQQEmail().isEmpty()));
    }

    @Test
    public void shouldReadStudentsWithEmailAndBaiduLink() throws Exception {
        File excelFile = new File("files/教学记录表_软国Java编程实践_百度链接和QQ邮箱.xlsx");
        List<Student> students = ExcelReader.readStudentFromExcel(excelFile.getAbsolutePath());

        assertFalse("Should read student rows", students.isEmpty());
        Student firstStudent = students.get(0);
        assertFalse("Should capture student id", firstStudent.getId().isEmpty());
        assertFalse("Should capture QQ email", firstStudent.getQQEmail().isEmpty());
        assertFalse("Should capture Baidu link", firstStudent.getBaiduLink().isEmpty());
    }
}
