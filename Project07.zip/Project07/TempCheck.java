﻿import java.util.List;
import edu.dalianligongdaxue.com.Project07.ExcelReader;
import edu.dalianligongdaxue.com.Project07.Student;
public class TempCheck {
    public static void main(String[] args) throws Exception {
        List<Student> students = ExcelReader.readStudentFromExcel("files/教学记录表_软国Java编程实践_百度链接和QQ邮箱.xlsx");
        System.out.println("size=" + students.size());
        for (int i = 0; i < Math.min(students.size(), 10); i++) {
            Student s = students.get(i);
            System.out.println((i + 1) + " | id=" + s.getId() + " | name=" + s.getName() + " | email=" + s.getQQEmail());
        }
    }
}
